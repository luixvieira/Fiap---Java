public class Celular {
    String nome;
    String sistemaOperacional;
    int espacoArmazenamento;
    float tamanhoTela;
}
