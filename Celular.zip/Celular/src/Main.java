import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner leitorDeDados = new Scanner(System.in);
       Celular celularA = new Celular();
        System.out.println("Digite o nome do celular");
       celularA.nome = leitorDeDados.next();
       System.out.println("Ok, seu celular é "+celularA.nome+" Agora digite o espaço de armazenamento:");

       celularA.espacoArmazenamento = leitorDeDados.nextInt();
       System.out.println("Ok, o espaço de armazenamento é de: "+celularA.espacoArmazenamento +" Agora digite o sistema operacional");

       celularA.sistemaOperacional = leitorDeDados.next();
       System.out.println("Ok, o sistema operacional é "+celularA.sistemaOperacional+" Agora digite o tamanho da tela.");

       celularA.tamanhoTela = leitorDeDados.nextFloat();
       System.out.println("O seu celular é um "+celularA.nome+" com o sistema operacional "+celularA.sistemaOperacional+" o espaco de armazenamento de "+celularA.espacoArmazenamento+ " e com a tela de "+celularA.tamanhoTela+".");
        }
    }
