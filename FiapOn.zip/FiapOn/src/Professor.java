package entidades;

public class Professor {

    private String nomeProfessor;

    public Professor(String nomeProfessor) {
        this.nomeProfessor = nomeProfessor;
    }

    public String getNome() {
        return nomeProfessor;
    }
}