package entidades;

public class RoteiroAula {

    private String diciplina;
    private String nomeAula;
    private String conteudoAula;

    public RoteiroAula(String diciplina, String nomeAula, String conteudoAula) {
        this.diciplina = diciplina;
        this.nomeAula = nomeAula;
        this.conteudoAula = conteudoAula;
    }

    public String getDiciplina() {
        return diciplina;
    }

    public String getNomeAula() {
        return nomeAula;
    }

    public String getConteudoAula() {
        return conteudoAula;
    }
}