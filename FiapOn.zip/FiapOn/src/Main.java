
import java.util.ArrayList;
import java.util.Scanner;

import entidades.Professor;
import entidades.RoteiroAula;

public class Main {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        ArrayList<RoteiroAula> roteiros = new ArrayList<>();

        System.out.println("Bem vindo professor! Por favor, digite seu nome:");
        String nomeProfessor = leitor.nextLine();
        Professor professor0 = new Professor(nomeProfessor);
        System.out.println("Olá prof. " + professor0.getNome() + "!");

        boolean cadastrarRoteiro = true;
        while (cadastrarRoteiro) {
            System.out.println("Digite a disciplina a ser ministrada:");
            String diciplina = leitor.nextLine();

            System.out.println("Certo. Informe também o nome da aula:");
            String nomeAula = leitor.nextLine();

            System.out.println("Por último, informe o conteúdo da aula:");
            String conteudoAula = leitor.nextLine();

            RoteiroAula aula = new RoteiroAula(diciplina, nomeAula, conteudoAula);
            roteiros.add(aula);

            System.out.println("Roteiro cadastrado Prof. " + professor0.getNome()
                    + ". Deseja cadastrar mais algum roteiro?\n"
                    + "1- Sim, 2- Não");

            int opcao = leitor.nextInt();leitor.nextLine();

            if (opcao == 2) {
                cadastrarRoteiro = false;

            } else if (opcao > 2) {
                System.out.println("Opção não disponivel");
                cadastrarRoteiro = false;

            }
        }
        System.out.println("Os roteiros cadastrados foram:");

        for(RoteiroAula roteiro : roteiros) {
            System.out.println("- Disciplina: " + roteiro.getDiciplina() + ". Aula: "
                    + roteiro.getNomeAula() + ". Conteúdo: " + roteiro.getConteudoAula());

        }

        leitor.close();
    }
}